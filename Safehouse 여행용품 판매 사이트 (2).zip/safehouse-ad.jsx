const { CompositionStage, useComposition, Easing, clamp, TweaksPanel, TweakSection, TweakToggle, useTweaks } = window;

const MOTION = {
  enter: (T, s, d = 0.6) => Easing.easeOutCubic(clamp((T - s) / d, 0, 1)),
  draw: (T, s, d = 0.8) => Easing.easeInOutCubic(clamp((T - s) / d, 0, 1)),
  pop: (T, s, d = 0.5) => Easing.easeOutBack(clamp((T - s) / d, 0, 1)),
};
const lerp = (a, b, p) => a + (b - a) * p;
const lin = (T, s, e) => clamp((T - s) / (e - s), 0, 1);
const won = n => '₩' + Math.round(n).toLocaleString('ko-KR');

const SERIF = "'Noto Serif KR', serif";
const SANS = "'Noto Sans KR', sans-serif";
const MONO = "'IBM Plex Mono', monospace";
const GOLD = '#c9a978', CREAM = '#ece6dc', MUTED = '#b8afa2';

function Backdrop() {
  const { T, authoredTotal } = useComposition();
  const x = lerp(30, 70, lin(T, 0, authoredTotal));
  return <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(60% 70% at ${x}% 60%, #221c16 0%, #0a0908 70%)` }} />;
}

function Night() {
  const { T, CUES } = useComposition();
  const s = CUES.Night, e = CUES.Reveal;
  const op = MOTION.enter(T, s, 0.9) * (1 - MOTION.draw(T, e - 0.35, 0.7));
  const sc = lerp(1.2, 1.05, lin(T, s, e + 0.4));
  const l1 = MOTION.enter(T, s + 0.4, 0.7), l2 = MOTION.enter(T, s + 1.1, 0.7);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: op, overflow: 'hidden' }}>
      <img src="assets/scene_carrier.png" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${sc})`, transformOrigin: '60% 55%' }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(10,9,8,0.96) 0%, rgba(10,9,8,0.75) 50%, rgba(10,9,8,0.2) 100%)' }} />
      <div style={{ position: 'absolute', left: 120, top: 500, display: 'flex', flexDirection: 'column', gap: 10, fontFamily: SANS, color: '#fff', fontWeight: 900, letterSpacing: '-0.02em' }}>
        <span style={{ fontSize: 120, opacity: l1, transform: `translateY(${(1 - l1) * 30}px)` }}>비 내린 새벽,</span>
        <span style={{ fontSize: 120, opacity: l2, transform: `translateY(${(1 - l2) * 30}px)` }}>어두운 골목길에서도</span>
      </div>
    </div>
  );
}

function glowColor(T, CUES) {
  const s = CUES.Light;
  if (T >= s + 1.35 && T < CUES.Offer) return '255,74,61';
  if (T >= s + 0.85 && T < CUES.Offer) return '127,182,255';
  if (T >= s + 0.35 && T < CUES.Offer) return '242,237,228';
  return '201,169,120';
}

function Carrier() {
  const { T, CUES } = useComposition();
  const appear = MOTION.enter(T, CUES.Reveal - 0.15, 1.0);
  const m = MOTION.draw(T, CUES.Finger - 0.25, 0.8);
  const out = MOTION.draw(T, CUES.End - 0.2, 0.6);
  const h = lerp(880, 820, m), w = h * 390 / 585;
  const left = lerp(1080, 170, m), top = lerp(110, 150, m) + (1 - appear) * 90;
  const breathe = 1 + 0.015 * Math.sin(T * 2.2);
  const c = glowColor(T, CUES);
  return (
    <div style={{ position: 'absolute', left, top, width: w, height: h, opacity: appear * (1 - out) }}>
      <div style={{ position: 'absolute', left: -w * 0.45, top: h * 0.05, width: w * 1.9, height: h * 0.95, borderRadius: '50%', background: `radial-gradient(closest-side, rgba(${c},0.38), rgba(${c},0) 100%)`, transform: `scale(${breathe})` }} />
      <img src="assets/c_hero.png" style={{ position: 'relative', width: '100%', height: '100%', objectFit: 'cover', borderRadius: 24, boxShadow: '0 40px 80px -20px rgba(0,0,0,0.8)' }} />
    </div>
  );
}

function RevealTitle() {
  const { T, CUES } = useComposition();
  const s = CUES.Reveal, out = MOTION.draw(T, CUES.Finger - 0.4, 0.5);
  const a = MOTION.enter(T, s + 0.3), b = MOTION.enter(T, s + 0.55), c = MOTION.enter(T, s + 0.8), d = MOTION.enter(T, s + 1.05);
  const line = (p, txt, color) => <span style={{ opacity: p, transform: `translateY(${(1 - p) * 34}px)`, color: color || CREAM }}>{txt}</span>;
  return (
    <div style={{ position: 'absolute', left: 110, top: 230, display: 'flex', flexDirection: 'column', gap: 28, opacity: 1 - out, transform: `translateX(${-out * 60}px)` }}>
      <span style={{ fontFamily: SANS, fontSize: 40, fontWeight: 700, letterSpacing: '0.12em', color: GOLD, opacity: a }}>SAFEHOUSE 스마트 캐리어</span>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontFamily: SANS, fontSize: 108, fontWeight: 900, lineHeight: 1.2, letterSpacing: '-0.02em' }}>
        {line(b, '지문으로 열리고,')}
        {line(c, '폰이 충전되고,')}
        {line(d, '밤길을 밝힌다', '#f0c987')}
      </div>
    </div>
  );
}

const FEATURES = [
  { cue: 'Finger', next: 'Charge', img: 'assets/c_finger2.png', label: '지문 잠금', stat: '0.3초', sub: '손가락만 대면 열려요' },
  { cue: 'Charge', next: 'Light', img: 'assets/c_charge2.png', label: '무선충전', stat: '15W', sub: '올려두면 바로 충전' },
  { cue: 'Light', next: 'Offer', img: 'assets/c_led.png', label: 'LED 라이트', stat: '3가지 빛', sub: '밤길에도 안전하게' },
];
const MODES = [['일반', '242,237,228', 0.35], ['보행', '127,182,255', 0.85], ['경고', '255,74,61', 1.35]];

function Feature({ f, i }) {
  const { T, CUES } = useComposition();
  const s = CUES[f.cue], e = CUES[f.next];
  const d0 = i === 0 ? 0.4 : -0.05;
  const inP = MOTION.enter(T, s + d0, 0.6), outP = MOTION.draw(T, e - 0.3, 0.4);
  const x = (1 - inP) * 90 - outP * 90;
  const imgSc = lerp(1.14, 1.0, lin(T, s, e + 0.3));
  const st = MOTION.pop(T, s + d0 + 0.3, 0.55);
  return (
    <div style={{ position: 'absolute', left: 780, top: 80, width: 1040, opacity: inP * (1 - outP), transform: `translateX(${x}px)` }}>
      <div style={{ width: 1040, height: 340, borderRadius: 28, overflow: 'hidden', background: '#171513' }}>
        <img src={f.img} style={{ width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${imgSc})` }} />
      </div>
      <div style={{ marginTop: 40, display: 'flex', alignItems: 'center', gap: 22 }}>
        <span style={{ width: 72, height: 72, borderRadius: '50%', background: GOLD, color: '#1a1612', fontFamily: SANS, fontSize: 40, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{i + 1}</span>
        <span style={{ fontFamily: SANS, fontSize: 72, fontWeight: 900, color: '#fff', letterSpacing: '-0.02em' }}>{f.label}</span>
      </div>
      <div style={{ marginTop: 6, fontFamily: SANS, fontSize: 250, fontWeight: 900, color: '#f0c987', lineHeight: 1.05, letterSpacing: '-0.04em', transform: `scale(${0.6 + 0.4 * st})`, transformOrigin: 'left bottom', opacity: clamp(st * 1.5, 0, 1) }}>{f.stat}</div>
      <div style={{ marginTop: 4, fontFamily: SANS, fontSize: 56, fontWeight: 700, color: CREAM, opacity: MOTION.enter(T, s + d0 + 0.55) }}>{f.sub}</div>
      {i === 2 && (
        <div style={{ position: 'absolute', left: 24, top: 236, display: 'flex', gap: 16 }}>
          {MODES.map(([n, c, d]) => {
            const on = MOTION.pop(T, s + d, 0.4);
            return (
              <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 14, background: 'rgba(10,9,8,0.82)', borderRadius: 999, padding: '18px 30px', opacity: 0.35 + 0.65 * clamp(on, 0, 1) }}>
                <span style={{ width: 64, height: 10, borderRadius: 5, background: `rgb(${c})`, boxShadow: `0 0 ${24 * clamp(on, 0, 1)}px 4px rgba(${c},0.7)` }} />
                <span style={{ fontFamily: SANS, fontSize: 40, color: '#fff', fontWeight: 900 }}>{n}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Offer() {
  const { T, CUES } = useComposition();
  const s = CUES.Offer, out = MOTION.draw(T, CUES.End - 0.3, 0.5);
  const inP = MOTION.enter(T, s - 0.05, 0.6);
  const chip = MOTION.pop(T, s + 0.1, 0.5);
  const was = MOTION.enter(T, s + 0.3, 0.5), strike = MOTION.draw(T, s + 0.6, 0.4);
  const drop = MOTION.draw(T, s + 0.7, 0.9);
  const price = lerp(259000, 139000, drop);
  const pricePop = MOTION.pop(T, s + 1.55, 0.4);
  const sub = MOTION.enter(T, s + 1.2, 0.6);
  return (
    <div style={{ position: 'absolute', left: 790, top: 200, display: 'flex', flexDirection: 'column', gap: 24, opacity: inP * (1 - out), transform: `translateX(${(1 - inP) * 90}px)` }}>
      <span style={{ alignSelf: 'flex-start', background: '#b23a2e', color: '#fff', fontFamily: SANS, fontSize: 52, fontWeight: 900, padding: '14px 36px', borderRadius: 999, transform: `scale(${chip})`, transformOrigin: 'left center' }}>46% 할인</span>
      <span style={{ position: 'relative', alignSelf: 'flex-start', fontFamily: SANS, fontSize: 64, fontWeight: 700, color: '#9a9083', opacity: was }}>
        정가 ₩259,000
        <span style={{ position: 'absolute', left: 0, top: '54%', height: 7, width: `${strike * 100}%`, background: '#e0564a' }} />
      </span>
      <span style={{ fontFamily: SANS, fontSize: 250, fontWeight: 900, color: '#f0c987', lineHeight: 1, letterSpacing: '-0.02em', display: 'inline-block', transform: `scale(${1 + 0.06 * Math.sin(Math.PI * clamp(pricePop, 0, 1))})`, transformOrigin: 'left center', opacity: clamp(drop * 3, 0, 1) }}>{won(Math.round(price / 1000) * 1000)}</span>
      <span style={{ fontFamily: SANS, fontSize: 60, fontWeight: 900, color: '#fff', opacity: sub, transform: `translateY(${(1 - sub) * 20}px)` }}>+ 사은품 3종 · 무료배송</span>
    </div>
  );
}

function EndCard() {
  const { T, CUES, authoredTotal } = useComposition();
  const s = CUES.End;
  const a = MOTION.enter(T, s + 0.15, 0.7), line = MOTION.draw(T, s + 0.4, 0.7), tag = MOTION.enter(T, s + 0.6, 0.6);
  const out = MOTION.draw(T, authoredTotal - 0.35, 0.35);
  const sc = lerp(0.97, 1.02, lin(T, s, authoredTotal));
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, opacity: 1 - out, transform: `scale(${sc})` }}>
      <span style={{ fontFamily: SERIF, fontSize: 120, fontWeight: 700, letterSpacing: '0.16em', color: CREAM, opacity: a, transform: `translateY(${(1 - a) * 24}px)` }}>SAFEHOUSE CAFÉ</span>
      <span style={{ width: 360 * line, height: 2, background: GOLD }} />
      <span style={{ fontFamily: SANS, fontSize: 44, fontWeight: 700, letterSpacing: '0.2em', color: GOLD, opacity: tag }}>스마트 트래블 캐리어</span>
      <span style={{ fontFamily: SANS, fontSize: 52, fontWeight: 700, color: '#fff', opacity: tag, marginTop: 18 }}>지금 홈페이지에서 만나보세요</span>
    </div>
  );
}

function Piece() {
  const { T } = useComposition();
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: '#0a0908' }}>
      <Backdrop />
      <Night />
      <Carrier />
      <RevealTitle />
      {FEATURES.map((f, i) => <Feature key={f.cue} f={f} i={i} />)}
      <Offer />
      <EndCard />
    </div>
  );
}

function SafehouseAd() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true });
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#0a0908">
        <Piece />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Motion" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </>
  );
}
window.SafehouseAd = SafehouseAd;
